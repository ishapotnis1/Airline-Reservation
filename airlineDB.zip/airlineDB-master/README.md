# airlineDB
This is an airline reservation sysem developed using Bootstrap, PHP, HTML5, CSS3 and MySQL. 
The system incorporates all the functionalities associated with a reservation system. The system incorporates security and encryption mechanisms.
